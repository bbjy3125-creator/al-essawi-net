# دليل استخراج ملف APK لتطبيق العيساوي نت | AL-ESSAWI NET

هذا المجلد هو مشروع أندرويد جاهز بالكامل (`iq.alessawinet.isp`) ويحتوي بداخله على واجهة التطبيق المدمجة.

## الطريقة 1: استخراج الـ APK تلقائياً عبر GitHub (الأسرع — دون تثبيت أي برامج)
1. أنشئ مستودعاً (Repository) جديداً على حسابك في GitHub وارفع ملفات هذا المجلد إليه.
2. افتح تبويب **Actions** داخل المستودع واضغط **Run workflow** (أو سيعمل تلقائياً فور الرفع).
3. بعد ~2 دقيقة، نزّل ملف **al-essawi-net-apk** (يحتوي على `app-debug.apk`) وثبّته مباشرة على هاتفك الأندرويد.

## الطريقة 2: عبر Android Studio على الكمبيوتر
1. افتح هذا المجلد في **Android Studio**.
2. انتظر انتهاء Gradle Sync، ثم من القائمة العلوية اختر:
   `Build -> Build Bundle(s) / APK(s) -> Build APK(s)`
3. ستجد الملف الجاهز في: `app/build/outputs/apk/debug/app-debug.apk`.

## ربط الـ APK بسيرفرك الفعلي (MikroTik & FreeRADIUS)
افتح الملف `app/src/main/java/iq/alessawinet/isp/MainActivity.java` وغيّر السطر:
```java
private static final String APP_URL = "file:///android_asset/www/index.html";
```
إلى عنوان سيرفرك الفعلي، مثلاً:
```java
private static final String APP_URL = "http://192.168.1.100:4000";
```
ثم أعد بناء الـ APK ليتصل التطبيق مباشرة بخادم PostgreSQL وMikroTik وFreeRADIUS على شبكتك.
