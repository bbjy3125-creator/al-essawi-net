# AL-ESSAWI NET ProGuard rules
